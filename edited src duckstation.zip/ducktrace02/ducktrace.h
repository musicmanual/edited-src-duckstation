#pragma once

// DuckTrace function-entry tracing.
//
// Injected DuckStation functions call:
//
//     DuckTrace("unique-function-id");
//
// The external ducktrace_controller.py edits
// ducktrace_functions.txt to decide which functions
// are actually written to the trace file.

void DuckTrace(const char* function_name);

void DuckTraceInstruction(
    unsigned int address,
    unsigned int instruction_bits,
    const char* disassembly,
    const char* comment);
