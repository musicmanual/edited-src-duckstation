#!/usr/bin/env python3
"""
DuckTrace Controller

Simple external GUI for selecting which injected DuckStation functions
should actually produce trace output.

It edits:
    /home/lainforall/ducktrace/ducktrace_functions.txt

0 = do not trace
1 = trace

Run:
    python3 ducktrace_controller.py
"""

from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import ttk


CONFIG_PATH = Path(
    "/home/lainforall/ducktrace/ducktrace_functions.txt"
)


class DuckTraceController:
    def __init__(self, root: tk.Tk):
        self.root = root

        self.root.title(
            "DuckTrace Controller"
        )

        self.root.geometry(
            "900x700"
        )

        self.functions: list[str] = []
        self.vars: dict[str, tk.BooleanVar] = {}

        self.create_ui()
        self.load_config()

    def create_ui(self):
        top = ttk.Frame(
            self.root,
            padding=10,
        )
        top.pack(
            fill="x",
        )

        ttk.Label(
            top,
            text="Search:",
        ).pack(
            side="left",
        )

        self.search_var = tk.StringVar()

        search = ttk.Entry(
            top,
            textvariable=self.search_var,
        )
        search.pack(
            side="left",
            fill="x",
            expand=True,
            padx=8,
        )

        self.search_var.trace_add(
            "write",
            lambda *_: self.refresh_list(),
        )

        buttons = ttk.Frame(
            self.root,
            padding=(10, 0, 10, 10),
        )
        buttons.pack(
            fill="x",
        )

        ttk.Button(
            buttons,
            text="Select All",
            command=self.select_all,
        ).pack(
            side="left",
            padx=3,
        )

        ttk.Button(
            buttons,
            text="Unselect All",
            command=self.unselect_all,
        ).pack(
            side="left",
            padx=3,
        )

        ttk.Button(
            buttons,
            text="Reload",
            command=self.load_config,
        ).pack(
            side="left",
            padx=3,
        )

        self.status = ttk.Label(
            buttons,
            text="",
        )
        self.status.pack(
            side="right",
        )

        container = ttk.Frame(
            self.root,
            padding=10,
        )
        container.pack(
            fill="both",
            expand=True,
        )

        self.canvas = tk.Canvas(
            container,
        )

        scrollbar = ttk.Scrollbar(
            container,
            orient="vertical",
            command=self.canvas.yview,
        )

        self.list_frame = ttk.Frame(
            self.canvas,
        )

        self.list_frame.bind(
            "<Configure>",
            lambda _event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )

        self.canvas_window = (
            self.canvas.create_window(
                (0, 0),
                window=self.list_frame,
                anchor="nw",
            )
        )

        self.canvas.bind(
            "<Configure>",
            self.on_canvas_resize,
        )

        self.canvas.configure(
            yscrollcommand=scrollbar.set,
        )

        self.canvas.pack(
            side="left",
            fill="both",
            expand=True,
        )

        scrollbar.pack(
            side="right",
            fill="y",
        )

        bottom = ttk.Frame(
            self.root,
            padding=10,
        )
        bottom.pack(
            fill="x",
        )

        ttk.Button(
            bottom,
            text="Apply",
            command=self.apply,
        ).pack(
            side="right",
        )

    def on_canvas_resize(self, event):
        self.canvas.itemconfigure(
            self.canvas_window,
            width=event.width,
        )

    def load_config(self):
        if not CONFIG_PATH.exists():
            self.functions.clear()
            self.vars.clear()
            self.refresh_list()

            self.status.config(
                text=(
                    "Config file not found: "
                    f"{CONFIG_PATH}"
                )
            )
            return

        old_states = {
            name: var.get()
            for name, var in self.vars.items()
        }

        self.functions.clear()
        self.vars.clear()

        with CONFIG_PATH.open(
            "r",
            encoding="utf-8",
        ) as f:
            for raw_line in f:
                line = raw_line.strip()

                if not line:
                    continue

                if line.startswith("#"):
                    continue

                if "|" not in line:
                    continue

                state, name = line.split(
                    "|",
                    1,
                )

                name = name.strip()

                if not name:
                    continue

                enabled = (
                    state.strip().lower()
                    in ("1", "true", "yes", "on")
                )

                # Preserve checkbox state if the user presses Reload.
                if name in old_states:
                    enabled = old_states[name]

                self.functions.append(name)

                self.vars[name] = tk.BooleanVar(
                    value=enabled
                )

        self.refresh_list()

        selected = sum(
            1
            for var in self.vars.values()
            if var.get()
        )

        self.status.config(
            text=(
                f"{selected} selected / "
                f"{len(self.functions)} total"
            )
        )

    def refresh_list(self):
        for widget in self.list_frame.winfo_children():
            widget.destroy()

        search = (
            self.search_var.get()
            .strip()
            .lower()
        )

        visible = 0

        for name in self.functions:
            if search and search not in name.lower():
                continue

            check = ttk.Checkbutton(
                self.list_frame,
                text=name,
                variable=self.vars[name],
            )

            check.pack(
                anchor="w",
                fill="x",
                pady=1,
            )

            visible += 1

        selected = sum(
            1
            for var in self.vars.values()
            if var.get()
        )

        self.status.config(
            text=(
                f"{selected} selected / "
                f"{visible} shown / "
                f"{len(self.functions)} total"
            )
        )

    def select_all(self):
        search = (
            self.search_var.get()
            .strip()
            .lower()
        )

        for name in self.functions:
            if not search or search in name.lower():
                self.vars[name].set(True)

        self.refresh_list()

    def unselect_all(self):
        search = (
            self.search_var.get()
            .strip()
            .lower()
        )

        for name in self.functions:
            if not search or search in name.lower():
                self.vars[name].set(False)

        self.refresh_list()

    def apply(self):
        if not CONFIG_PATH.exists():
            self.status.config(
                text="Config file does not exist."
            )
            return

        # Write a temporary file first, then atomically replace the
        # configuration. DuckTrace will therefore never see a half-written
        # configuration file.
        temp_path = CONFIG_PATH.with_suffix(
            ".tmp"
        )

        with temp_path.open(
            "w",
            encoding="utf-8",
            newline="\n",
        ) as f:
            f.write(
                "# DuckTrace function configuration\n"
            )
            f.write(
                "# 0 = do not trace, 1 = trace\n\n"
            )

            for name in self.functions:
                enabled = self.vars[name].get()

                f.write(
                    f"{1 if enabled else 0}|{name}\n"
                )

        temp_path.replace(CONFIG_PATH)

        selected = sum(
            1
            for var in self.vars.values()
            if var.get()
        )

        self.status.config(
            text=(
                f"Applied: {selected} selected / "
                f"{len(self.functions)} total"
            )
        )


def main():
    root = tk.Tk()

    DuckTraceController(root)

    root.mainloop()


if __name__ == "__main__":
    main()
