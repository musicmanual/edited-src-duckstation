#!/usr/bin/env python3
"""
DuckStation C++ Function DuckTrace Injector

This version:
  - scans DuckStation C/C++ source files for function definitions
  - injects a unique DuckTrace("..."); call into every detected function
  - skips DuckTrace's own files and the external controller
  - creates .bak backups before modifying files
  - creates ducktrace_functions.txt with every function OFF by default
  - does NOT ask which functions to inject; the external controller handles
    trace selection at runtime

Usage:
    python3 inject_function_logs.py --src /home/lainforall/duckstation/src

Optional:
    --include-headers

Generated config:
    /home/lainforall/ducktrace/ducktrace_functions.txt

Example injected line:
    DuckTrace("core/system.cpp:1680:System::RunFrame");
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path


DUCKTRACE_DIR = Path("/home/lainforall/ducktrace")
CONFIG_PATH = DUCKTRACE_DIR / "ducktrace_functions.txt"

DUCKTRACE_HEADER_COMMON = '#include "ducktrace.h"'
DUCKTRACE_HEADER_OTHER = '#include "common/ducktrace.h"'

SOURCE_EXTENSIONS = {
    ".cpp", ".cc", ".cxx", ".c++",
    ".h", ".hh", ".hpp", ".hxx", ".h++",
}

CPP_EXTENSIONS = {".cpp", ".cc", ".cxx", ".c++"}

SKIP_DIR_NAMES = {
    ".git",
    "build",
    "build-debug",
    "build-debug-new",
    "build-debug-new-detailed",
    "node_modules",
}

SKIP_FILE_NAMES = {
    "ducktrace.cpp",
    "ducktrace.h",
    "ducktrace_functions.h",
    "ducktracedialog.cpp",
    "ducktracedialog.h",
    "mainwindow.cpp",
    "ducktrace_controller.py",
}


@dataclass
class FunctionInfo:
    path: Path
    name: str
    line: int
    open_brace: int
    close_brace: int


# ---------------------------------------------------------------------------
# C++ lexical scanning
# ---------------------------------------------------------------------------

def mask_comments_and_strings(source: str) -> str:
    """
    Replace comments and string/character literal contents with spaces while
    preserving newlines and character positions.

    This prevents braces inside comments and strings from confusing the
    function detector.
    """
    out = list(source)
    n = len(source)
    i = 0

    NORMAL = 0
    LINE_COMMENT = 1
    BLOCK_COMMENT = 2
    STRING = 3
    CHAR = 4
    RAW_STRING = 5

    state = NORMAL
    raw_end = ""

    while i < n:
        c = source[i]
        nxt = source[i + 1] if i + 1 < n else ""

        if state == NORMAL:
            if c == "/" and nxt == "/":
                out[i] = out[i + 1] = " "
                i += 2
                state = LINE_COMMENT
                continue

            if c == "/" and nxt == "*":
                out[i] = out[i + 1] = " "
                i += 2
                state = BLOCK_COMMENT
                continue

            # C++ raw string: R"delimiter(... )delimiter"
            if c == "R" and nxt == '"':
                j = i + 2
                while j < n and source[j] != "(":
                    if (
                        j - (i + 2) > 16
                        or source[j] in " \t\r\n\\()"
                    ):
                        break
                    j += 1

                if j < n and source[j] == "(":
                    delimiter = source[i + 2:j]
                    raw_end = ")" + delimiter + '"'

                    for k in range(i, j + 1):
                        if source[k] != "\n":
                            out[k] = " "

                    i = j + 1
                    state = RAW_STRING
                    continue

            if c == '"':
                out[i] = " "
                i += 1
                state = STRING
                continue

            if c == "'":
                out[i] = " "
                i += 1
                state = CHAR
                continue

            i += 1
            continue

        if state == LINE_COMMENT:
            if c == "\n":
                state = NORMAL
            else:
                out[i] = " "
            i += 1
            continue

        if state == BLOCK_COMMENT:
            if c == "*" and nxt == "/":
                out[i] = out[i + 1] = " "
                i += 2
                state = NORMAL
            else:
                if c != "\n":
                    out[i] = " "
                i += 1
            continue

        if state == STRING:
            if c == "\\":
                if c != "\n":
                    out[i] = " "
                if i + 1 < n:
                    if source[i + 1] != "\n":
                        out[i + 1] = " "
                    i += 2
                else:
                    i += 1
                continue

            if c == '"':
                out[i] = " "
                i += 1
                state = NORMAL
            else:
                if c != "\n":
                    out[i] = " "
                i += 1
            continue

        if state == CHAR:
            if c == "\\":
                if c != "\n":
                    out[i] = " "
                if i + 1 < n:
                    if source[i + 1] != "\n":
                        out[i + 1] = " "
                    i += 2
                else:
                    i += 1
                continue

            if c == "'":
                out[i] = " "
                i += 1
                state = NORMAL
            else:
                if c != "\n":
                    out[i] = " "
                i += 1
            continue

        if state == RAW_STRING:
            if source.startswith(raw_end, i):
                for k in range(i, min(n, i + len(raw_end))):
                    if source[k] != "\n":
                        out[k] = " "
                i += len(raw_end)
                state = NORMAL
            else:
                if c != "\n":
                    out[i] = " "
                i += 1
            continue

    for i, ch in enumerate(source):
        if ch == "\n":
            out[i] = "\n"

    return "".join(out)


def matching_pairs(masked: str):
    stacks = {"(": [], "[": [], "{": []}
    pairs = {}
    closing = {")": "(", "]": "[", "}": "{"}

    for i, c in enumerate(masked):
        if c in stacks:
            stacks[c].append(i)
        elif c in closing:
            opener = closing[c]
            if stacks[opener]:
                start = stacks[opener].pop()
                pairs[start] = i

    return pairs


# ---------------------------------------------------------------------------
# Function detection
# ---------------------------------------------------------------------------

CONTROL_WORDS = {
    "if", "else", "for", "while", "switch", "case", "default",
    "try", "catch", "do", "sizeof", "decltype", "requires",
}

NON_FUNCTION_PREFIXES = {
    "namespace", "class", "struct", "union", "enum",
    "extern", "using", "typedef", "static_assert",
}


def line_number(source: str, offset: int) -> int:
    return source.count("\n", 0, offset) + 1


def previous_nonspace(masked: str, pos: int) -> int:
    pos -= 1
    while pos >= 0 and masked[pos].isspace():
        pos -= 1
    return pos


def statement_start(masked: str, pos: int) -> int:
    i = pos - 1
    paren = 0
    bracket = 0

    while i >= 0:
        c = masked[i]

        if c == ")":
            paren += 1
        elif c == "(":
            if paren:
                paren -= 1
        elif c == "]":
            bracket += 1
        elif c == "[":
            if bracket:
                bracket -= 1
        elif paren == 0 and bracket == 0 and c in ";{}":
            return i + 1

        i -= 1

    return 0


def normalize_fragment(fragment: str) -> str:
    return re.sub(r"\s+", " ", fragment).strip()


def line_start(source: str, pos: int) -> int:
    return source.rfind("\n", 0, pos) + 1


def line_end(source: str, pos: int) -> int:
    end = source.find("\n", pos)
    return len(source) if end < 0 else end


def has_preprocessor_directive_near(source: str, pos: int) -> bool:
    current = line_start(source, pos)

    for _ in range(64):
        start = current
        raw = source[start:line_end(source, start)]
        stripped = raw.lstrip()

        if stripped.startswith("#"):
            return True

        if raw.rstrip().endswith("\\") and start > 0:
            current = line_start(source, start - 1)
            continue

        break

    return False


def header_has_preprocessor_directive(header: str) -> bool:
    return any(
        re.match(r"^\s*#", line)
        for line in header.splitlines()
    )


def is_linkage_block(header: str) -> bool:
    h = normalize_fragment(header)
    return bool(
        re.match(r'^extern\s+"(?:C|C\+\+)"\s*$', h)
    )


def is_deleted_or_defaulted_function(header: str) -> bool:
    h = normalize_fragment(header)
    return bool(re.search(r"=\s*(?:delete|default)\s*$", h))


def is_macro_like_function_header(header: str) -> bool:
    h = normalize_fragment(header)

    if "#" in h:
        return True

    if re.match(r"^define\s+[A-Za-z_]\w*\s*\(", h):
        return True

    return False


def looks_like_control_block(header: str) -> bool:
    h = normalize_fragment(header)

    h = re.sub(
        r"^(public|private|protected|signals|slots)\s*:\s*",
        "",
        h,
        flags=re.IGNORECASE,
    )

    m = re.match(r"^([A-Za-z_]\w*)\b", h)

    if m and m.group(1) in CONTROL_WORDS:
        return True

    if re.match(r"^(else|do)\b", h):
        return True

    return False


def looks_like_nonfunction_block(header: str) -> bool:
    h = normalize_fragment(header)

    if not h:
        return True

    if header_has_preprocessor_directive(header):
        return True

    if is_macro_like_function_header(header):
        return True

    if is_linkage_block(header):
        return True

    if is_deleted_or_defaulted_function(header):
        return True

    if looks_like_control_block(h):
        return True

    if re.match(
        r"^(?:inline\s+)?(?:namespace|class|struct|union|enum)\b",
        h,
    ):
        return True

    # Lambdas are deliberately skipped.
    if re.search(
        r"(?:^|[=\(\[,])\s*\[[^\]]*\]\s*"
        r"(?:\([^;{}]*\))?\s*"
        r"(?:mutable\s*)?"
        r"(?:noexcept\b[^{}]*)?"
        r"(?:->[^{}]+)?\s*$",
        h,
    ):
        return True

    if "=" in h and not re.search(r"\boperator\s*=", h):
        if "(" not in h:
            return True

    if re.search(
        r"(?:\[\s*\]|\]\s*)(?:\s*=\s*|\s*)$",
        h,
    ):
        return True

    if re.search(r"\[[^\]]*\]\s*(?:=\s*)?$", h):
        return True

    if "(" not in h and re.search(r"\b[A-Za-z_]\w*\s*$", h):
        return True

    if "(" not in h and ")" not in h:
        return True

    return False


def extract_function_name(header: str) -> str | None:
    h = normalize_fragment(header)

    h = re.sub(
        r"^\s*(?:inline|static|virtual|explicit|constexpr|consteval|constinit)\b\s*",
        "",
        h,
    )

    matches = list(
        re.finditer(
            r"([~A-Za-z_]\w*(?:::[~A-Za-z_]\w*)*|operator\s*[^\s(]+)\s*\(",
            h,
        )
    )

    if matches:
        candidate = matches[-1].group(1).strip()

        if candidate in CONTROL_WORDS or candidate == "defined":
            return None

        return candidate

    return None


def is_non_runtime_function(header: str) -> bool:
    h = normalize_fragment(header)

    if re.search(r"\b(?:constexpr|consteval)\b", h):
        return True

    return False


def find_function_candidates(source: str) -> list[FunctionInfo]:
    masked = mask_comments_and_strings(source)
    pairs = matching_pairs(masked)

    candidates = []

    for open_brace, close_brace in pairs.items():

        prev = previous_nonspace(masked, open_brace)

        if prev < 0:
            continue

        start = statement_start(masked, open_brace)
        header = masked[start:open_brace]

        if has_preprocessor_directive_near(source, open_brace):
            continue

        if looks_like_nonfunction_block(header):
            continue

        if is_linkage_block(header):
            continue

        if is_non_runtime_function(header):
            continue

        name = extract_function_name(header)

        if not name:
            continue

        close_paren = header.rfind(")")

        if close_paren < 0:
            continue

        after_params = normalize_fragment(
            header[close_paren + 1:]
        )

        if re.search(
            r"\[[^\]]*\]\s*(?:=\s*)?$",
            after_params,
        ):
            continue

        if after_params:
            allowed_tail = re.compile(
                r"^(?:(?:const|volatile|mutable|override|final|noexcept)"
                r"(?:\s*\([^{};]*\))?\s*|"
                r"requires\s+[^{};]+\s*|"
                r"->\s*[^{};]+\s*|"
                r"\[\[[^]]*\]\]\s*)+$"
            )

            if not allowed_tail.fullmatch(after_params):
                continue

        local_pairs = matching_pairs(header)
        open_paren = None

        for op, cl in local_pairs.items():
            if cl == close_paren and header[op] == "(":
                open_paren = op
                break

        if open_paren is None:
            continue

        prefix = normalize_fragment(
            header[:open_paren]
        )

        first_word_match = re.match(
            r"^([A-Za-z_]\w*)\b",
            prefix,
        )

        if (
            first_word_match
            and first_word_match.group(1) in CONTROL_WORDS
        ):
            continue

        if not re.search(
            r"(?:^|[\w:~*&<>])\s*"
            r"(?:operator\s*[^\s(]+|~?[A-Za-z_]\w*(?:::[A-Za-z_]\w*)*)\s*\(",
            header,
        ):
            continue

        candidates.append(
            FunctionInfo(
                path=Path(),
                name=name,
                line=line_number(source, open_brace),
                open_brace=open_brace,
                close_brace=close_brace,
            )
        )

    unique = {}

    for c in candidates:
        unique[(c.open_brace, c.close_brace)] = c

    return sorted(
        unique.values(),
        key=lambda x: x.open_brace,
    )


# ---------------------------------------------------------------------------
# DuckTrace ID / config
# ---------------------------------------------------------------------------

def cpp_escape_string(value: str) -> str:
    return (
        value
        .replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "\\r")
    )


def make_trace_id(
    func: FunctionInfo,
    root: Path,
) -> str:
    relative = func.path.relative_to(root).as_posix()
    return f"{relative}:{func.line}:{func.name}"


def generate_config(
    root: Path,
    functions: list[FunctionInfo],
) -> Path:

    CONFIG_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    entries = []
    seen = set()

    for func in functions:
        trace_id = make_trace_id(func, root)

        if trace_id in seen:
            continue

        seen.add(trace_id)
        entries.append(trace_id)

    entries.sort()

    with CONFIG_PATH.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as f:
        f.write(
            "# DuckTrace function configuration\n"
        )
        f.write(
            "# 0 = do not trace, 1 = trace\n"
        )
        f.write(
            "# This file is generated by "
            "inject_function_logs.py\n"
        )
        f.write(
            "# You can change it with "
            "ducktrace_controller.py\n\n"
        )

        for trace_id in entries:
            f.write(f"0|{trace_id}\n")

    print()
    print("DuckTrace configuration created:")
    print(f"  {CONFIG_PATH}")
    print(f"  Functions: {len(entries)}")

    return CONFIG_PATH


# ---------------------------------------------------------------------------
# Injection
# ---------------------------------------------------------------------------

def already_injected(
    source: str,
    func: FunctionInfo,
) -> bool:

    body = source[
        func.open_brace:func.close_brace
    ]

    return "DuckTrace(" in body


def indentation_for_body(
    source: str,
    brace: int,
) -> str:

    line_start_pos = (
        source.rfind("\n", 0, brace) + 1
    )

    brace_line = source[
        line_start_pos:brace
    ]

    base = re.match(
        r"[ \t]*",
        brace_line,
    ).group(0)

    pos = brace + 1

    while pos < len(source):

        line_end_pos = source.find(
            "\n",
            pos,
        )

        if line_end_pos < 0:
            line_end_pos = len(source)

        line = source[
            pos:line_end_pos
        ]

        if line.strip():

            m = re.match(
                r"[ \t]*",
                line,
            )

            if m:
                return m.group(0)

            break

        pos = line_end_pos + 1

    return base + (
        "\t" if "\t" in base else "    "
    )


def get_ducktrace_header(
    path: Path,
    root: Path,
) -> str:

    try:
        relative = path.relative_to(root)
    except ValueError:
        return DUCKTRACE_HEADER_OTHER

    if relative.parent == Path("common"):
        return DUCKTRACE_HEADER_COMMON

    return DUCKTRACE_HEADER_OTHER


def _remove_ducktrace_includes(
    source: str,
) -> str:

    lines = source.splitlines(
        keepends=True
    )

    filtered = []

    for line in lines:

        if re.match(
            r'^\s*#\s*include\s*[<"]'
            r'(?:common/)?ducktrace\.h[">]',
            line,
        ):
            continue

        filtered.append(line)

    return "".join(filtered)


def add_ducktrace_header(
    source: str,
    path: Path,
    root: Path,
) -> str:

    ducktrace_header = get_ducktrace_header(
        path,
        root,
    )

    source = _remove_ducktrace_includes(
        source
    )

    newline = (
        "\r\n"
        if "\r\n" in source
        else "\n"
    )

    return (
        ducktrace_header
        + newline
        + source
    )


def validate_injection_position(
    source: str,
    func: FunctionInfo,
) -> bool:

    if not (
        0
        <= func.open_brace
        < func.close_brace
        <= len(source)
    ):
        return False

    if source[func.open_brace] != "{":
        return False

    if func.close_brace <= func.open_brace + 1:
        return False

    prefix = source[
        max(0, func.open_brace - 500):
        func.open_brace
    ]

    masked_prefix = mask_comments_and_strings(
        prefix
    )

    if re.search(
        r"\b(?:namespace|class|struct|union|enum)"
        r"\s+[A-Za-z_]\w*"
        r"(?:\s*::\s*[A-Za-z_]\w*)*\s*$",
        masked_prefix.strip(),
    ):
        return False

    if has_preprocessor_directive_near(
        source,
        func.open_brace,
    ):
        return False

    if is_linkage_block(masked_prefix):
        return False

    return True


def inject_into_file(
    path: Path,
    funcs: list[FunctionInfo],
    root: Path,
) -> tuple[bool, int]:

    source = path.read_text(
        encoding="utf-8",
        errors="surrogateescape",
    )

    changes = []

    if path.suffix.lower() not in CPP_EXTENSIONS:
        return False, 0

    valid_funcs = []

    for func in funcs:

        if not validate_injection_position(
            source,
            func,
        ):
            print(
                f"  SAFETY SKIP: "
                f"{path.name}:{func.line} "
                f"{func.name}"
            )
            continue

        if already_injected(
            source,
            func,
        ):
            continue

        valid_funcs.append(func)

    for func in valid_funcs:

        indent = indentation_for_body(
            source,
            func.open_brace,
        )

        trace_id = make_trace_id(
            func,
            root,
        )

        injection_line = (
            f'DuckTrace("{cpp_escape_string(trace_id)}");'
        )

        if (
            func.open_brace + 1 < len(source)
            and source[func.open_brace + 1] == "\n"
        ):
            insertion = (
                indent
                + injection_line
                + "\n"
            )

            offset = (
                func.open_brace + 2
            )

        else:
            insertion = (
                "\n"
                + indent
                + injection_line
                + "\n"
            )

            offset = (
                func.open_brace + 1
            )

        changes.append(
            (offset, insertion)
        )

    if not changes:
        return False, 0

    backup = Path(
        str(path) + ".bak"
    )

    if not backup.exists():
        shutil.copy2(
            path,
            backup,
        )

    for offset, text_to_insert in sorted(
        changes,
        reverse=True,
    ):
        source = (
            source[:offset]
            + text_to_insert
            + source[offset:]
        )

    source = add_ducktrace_header(
        source,
        path,
        root,
    )

    if not source.strip():
        print(
            f"  SAFETY ERROR: refusing "
            f"to write empty file: {path}"
        )
        return False, 0

    path.write_text(
        source,
        encoding="utf-8",
        errors="surrogateescape",
    )

    return True, len(changes)


# ---------------------------------------------------------------------------
# File scanning
# ---------------------------------------------------------------------------

def iter_source_files(
    root: Path,
    include_headers: bool,
):
    extensions = CPP_EXTENSIONS.copy()

    if include_headers:
        extensions |= {
            ".h", ".hh", ".hpp",
            ".hxx", ".h++",
        }

    for path in root.rglob("*"):

        if not path.is_file():
            continue

        if any(
            part in SKIP_DIR_NAMES
            for part in path.parts
        ):
            continue

        if path.name.lower() in {
            name.lower()
            for name in SKIP_FILE_NAMES
        }:
            continue

        if path.suffix.lower() in extensions:
            yield path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():

    parser = argparse.ArgumentParser(
        description=(
            "Find C++ functions, inject "
            "unique DuckTrace calls, and "
            "generate the external "
            "DuckTrace configuration."
        )
    )

    parser.add_argument(
        "--src",
        required=True,
        help=(
            "Source folder, e.g. "
            "/home/lainforall/duckstation/src"
        ),
    )

    parser.add_argument(
        "--include-headers",
        action="store_true",
        help=(
            "Also scan headers. "
            "Only .cpp/.cc/.cxx/.c++ "
            "files are modified."
        ),
    )

    args = parser.parse_args()

    root = Path(
        args.src
    ).expanduser().resolve()

    if not root.is_dir():
        print(
            f"ERROR: source directory "
            f"does not exist: {root}"
        )
        sys.exit(1)

    files = sorted(
        iter_source_files(
            root,
            args.include_headers,
        )
    )

    print(f"Source root: {root}")
    print(f"Files to scan: {len(files)}")
    print()

    all_functions: list[FunctionInfo] = []

    for i, path in enumerate(
        files,
        1,
    ):

        print(
            f"[{i}/{len(files)}] "
            f"{path.relative_to(root)}"
        )

        try:

            source = path.read_text(
                encoding="utf-8",
                errors="surrogateescape",
            )

            funcs = find_function_candidates(
                source
            )

            for func in funcs:
                func.path = path

            all_functions.extend(funcs)

        except Exception as e:

            print(
                f"    WARNING: {e}"
            )

    print()
    print("=" * 80)
    print(
        f"FUNCTIONS FOUND: "
        f"{len(all_functions)}"
    )
    print("=" * 80)

    for i, func in enumerate(
        all_functions,
        1,
    ):

        rel = func.path.relative_to(
            root
        )

        print(
            f"  [{i:5}] "
            f"{func.name} "
            f"({rel}:{func.line})"
        )

    if not all_functions:
        print()
        print("No functions found.")
        return

    # Always generate the configuration with
    # every function OFF.
    generate_config(
        root,
        all_functions,
    )

    print()
    print(
        "All detected functions will be "
        "instrumented."
    )
    print()
    print(
        "Function selection is NOT done "
        "by this script."
    )
    print(
        "Use ducktrace_controller.py "
        "after injection."
    )
    print()

    confirm = input(
        "Type APPLY to continue: "
    ).strip()

    if confirm != "APPLY":
        print(
            "Confirmation not received. "
            "No source files changed."
        )
        return

    by_file: dict[
        Path,
        list[FunctionInfo],
    ] = {}

    for func in all_functions:
        by_file.setdefault(
            func.path,
            [],
        ).append(func)

    print()
    print("Applying changes...")

    modified_files = 0
    injected_count = 0
    skipped_count = 0

    for path, funcs in sorted(
        by_file.items()
    ):

        try:

            changed, count = inject_into_file(
                path,
                funcs,
                root,
            )

            if changed:

                modified_files += 1
                injected_count += count

                print(
                    f"  MODIFIED: "
                    f"{path.relative_to(root)} "
                    f"({count} injection(s))"
                )

            else:

                skipped_count += 1

                print(
                    f"  SKIPPED:  "
                    f"{path.relative_to(root)} "
                    f"(already injected)"
                )

        except Exception as e:

            print(
                f"  ERROR: {path}: {e}"
            )

    print()
    print("=" * 80)
    print("DONE")
    print("=" * 80)
    print(
        f"Files modified: "
        f"{modified_files}"
    )
    print(
        f"DuckTrace lines inserted: "
        f"{injected_count}"
    )
    print(
        f"Files skipped: "
        f"{skipped_count}"
    )
    print()
    print(
        "Original files are backed up "
        "as *.bak"
    )
    print(
        "Injected form:"
    )
    print(
        '  DuckTrace("unique-function-ID");'
    )
    print()
    print(
        "Configuration:"
    )
    print(
        f"  {CONFIG_PATH}"
    )


if __name__ == "__main__":
    main()
