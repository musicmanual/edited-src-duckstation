#include "common/ducktrace.h"

#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <system_error>
#include <unordered_map>

namespace
{

// Keep these paths matching the external controller.
constexpr const char* TRACE_PATH =
    "/home/lainforall/ducktrace/duckstation_trace.txt";

constexpr const char* CONFIG_PATH =
    "/home/lainforall/ducktrace/ducktrace_functions.txt";

std::unordered_map<std::string, bool> s_function_states;

std::mutex s_mutex;

std::filesystem::file_time_type s_config_timestamp;

bool s_loaded = false;

void LoadConfig()
{
    std::ifstream file(CONFIG_PATH);

    if (!file.is_open())
    {
        // If the configuration file does not exist, everything stays OFF.
        s_function_states.clear();
        s_loaded = true;
        return;
    }

    std::unordered_map<std::string, bool> new_states;

    std::string line;

    while (std::getline(file, line))
    {
        if (line.empty())
            continue;

        // Allow comments in ducktrace_functions.txt.
        if (line[0] == '#')
            continue;

        const size_t separator = line.find('|');

        if (separator == std::string::npos)
            continue;

        const std::string state =
            line.substr(0, separator);

        const std::string function_name =
            line.substr(separator + 1);

        if (function_name.empty())
            continue;

        const bool enabled =
            state == "1" ||
            state == "true" ||
            state == "True";

        new_states[function_name] = enabled;
    }

    s_function_states = std::move(new_states);
    s_loaded = true;

    // DuckStation is built with -fno-exceptions, so use
    // the error_code overload instead of try/catch.
    std::error_code ec;

    const auto timestamp =
        std::filesystem::last_write_time(CONFIG_PATH, ec);

    if (!ec)
    {
        s_config_timestamp = timestamp;
    }
}

void CheckConfig()
{
    // DuckStation is built with -fno-exceptions, so use
    // the error_code overload instead of try/catch.
    std::error_code ec;

    const auto timestamp =
        std::filesystem::last_write_time(CONFIG_PATH, ec);

    if (!ec)
    {
        if (!s_loaded || timestamp != s_config_timestamp)
            LoadConfig();
    }
    else if (!s_loaded)
    {
        LoadConfig();
    }
}

bool IsFunctionEnabled(const char* function_name)
{
    std::lock_guard<std::mutex> lock(s_mutex);

    CheckConfig();

    const auto it =
        s_function_states.find(function_name);

    if (it == s_function_states.end())
    {
        // New or unknown functions are OFF by default.
        return false;
    }

    return it->second;
}

void WriteTraceLine(const char* text)
{
    if (!text)
        return;

    FILE* file =
        std::fopen(TRACE_PATH, "a");

    if (!file)
        return;

    std::fprintf(
        file,
        "%s\n",
        text);

    std::fflush(file);

    std::fclose(file);
}

} // namespace

void DuckTrace(const char* function_name)
{
    if (!function_name)
        return;

    // Only selected functions reach the file.
    if (!IsFunctionEnabled(function_name))
        return;

    WriteTraceLine(function_name);
}

void DuckTraceInstruction(
    unsigned int address,
    unsigned int instruction_bits,
    const char* disassembly,
    const char* comment)
{
    FILE* file =
        std::fopen(TRACE_PATH, "a");

    if (!file)
        return;

    std::fprintf(
        file,
        "MY_LABEL: address=0x%08X, opcode=0x%08X, disassembly=%s, extra=%s\n",
        address,
        instruction_bits,
        disassembly ? disassembly : "",
        comment ? comment : "");

    std::fflush(file);

    std::fclose(file);
}
