#!/usr/bin/env python3
"""
DuckTrace Terminal Controller

Terminal-only controller for selecting which injected DuckStation
functions should produce trace output.

Config:
    /home/lainforall/ducktrace/ducktrace_functions.txt

Format:
    0|function_name   = OFF
    1|function_name   = ON

Usage examples:

    python3 ducktrace_controller.py
    python3 ducktrace_controller.py --list
    python3 ducktrace_controller.py --list-enabled
    python3 ducktrace_controller.py --search System
    python3 ducktrace_controller.py --enable "core/system.cpp:1680:System::RunFrame"
    python3 ducktrace_controller.py --disable "core/system.cpp:1680:System::RunFrame"
    python3 ducktrace_controller.py --enable-all
    python3 ducktrace_controller.py --disable-all
"""

from __future__ import annotations

import argparse
import os
import sys
import tempfile
from pathlib import Path


CONFIG_PATH = Path(
    "/home/lainforall/ducktrace/ducktrace_functions.txt"
)


def load_config() -> list[tuple[bool, str]]:
    if not CONFIG_PATH.exists():
        print(f"ERROR: Config file not found:")
        print(f"  {CONFIG_PATH}")
        sys.exit(1)

    functions: list[tuple[bool, str]] = []

    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.strip()

            if not line or line.startswith("#"):
                continue

            if "|" not in line:
                continue

            state, name = line.split("|", 1)
            name = name.strip()

            if not name:
                continue

            enabled = state.strip().lower() in (
                "1",
                "true",
                "yes",
                "on",
            )

            functions.append((enabled, name))

    return functions


def save_config(functions: list[tuple[bool, str]]) -> None:
    """
    Write a temporary file and atomically replace the config.
    This prevents DuckTrace from seeing a half-written file.
    """
    fd, temp_name = tempfile.mkstemp(
        prefix="ducktrace_",
        suffix=".tmp",
        dir=str(CONFIG_PATH.parent),
        text=True,
    )

    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write("# DuckTrace function configuration\n")
            f.write("# 0 = do not trace, 1 = trace\n\n")

            for enabled, name in functions:
                f.write(f"{1 if enabled else 0}|{name}\n")

        os.replace(temp_name, CONFIG_PATH)

    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def find_matches(
    functions: list[tuple[bool, str]],
    search: str,
) -> list[int]:
    search_lower = search.lower()

    return [
        i
        for i, (_, name) in enumerate(functions)
        if search_lower in name.lower()
    ]


def print_function(index: int, enabled: bool, name: str) -> None:
    state = "ON " if enabled else "OFF"
    print(f"[{index:5}] {state} | {name}")


def list_functions(
    functions: list[tuple[bool, str]],
    search: str = "",
    enabled_only: bool = False,
) -> None:
    shown = 0

    for index, (enabled, name) in enumerate(functions):
        if enabled_only and not enabled:
            continue

        if search and search.lower() not in name.lower():
            continue

        print_function(index, enabled, name)
        shown += 1

    print()
    print(
        f"Showing {shown} / {len(functions)} functions"
    )


def set_function(
    functions: list[tuple[bool, str]],
    name: str,
    enabled: bool,
) -> int:
    """
    Enable/disable all exact matches.
    Returns number of changed entries.
    """
    changed = 0

    for i, (old_state, old_name) in enumerate(functions):
        if old_name == name:
            if old_state != enabled:
                functions[i] = (enabled, old_name)
                changed += 1

    return changed


def set_matching(
    functions: list[tuple[bool, str]],
    search: str,
    enabled: bool,
) -> int:
    """
    Enable/disable every function containing the search text.
    """
    changed = 0

    for i, (old_state, old_name) in enumerate(functions):
        if search.lower() in old_name.lower():
            if old_state != enabled:
                functions[i] = (enabled, old_name)
                changed += 1

    return changed


def show_status(functions: list[tuple[bool, str]]) -> None:
    enabled = sum(1 for state, _ in functions if state)

    print()
    print("=" * 70)
    print("DuckTrace status")
    print("=" * 70)
    print(f"Enabled : {enabled}")
    print(f"Disabled: {len(functions) - enabled}")
    print(f"Total   : {len(functions)}")
    print(f"Config  : {CONFIG_PATH}")
    print("=" * 70)


def interactive_mode() -> None:
    while True:
        functions = load_config()

        show_status(functions)

        print()
        print("1. List all functions")
        print("2. List enabled functions")
        print("3. Search functions")
        print("4. Enable function")
        print("5. Disable function")
        print("6. Enable matching functions")
        print("7. Disable matching functions")
        print("8. Enable ALL")
        print("9. Disable ALL")
        print("0. Exit")
        print()

        try:
            choice = input("Choice: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if choice == "0":
            return

        if choice == "1":
            list_functions(functions)

        elif choice == "2":
            list_functions(functions, enabled_only=True)

        elif choice == "3":
            search = input("Search: ").strip()

            if not search:
                print("Search cannot be empty.")
                continue

            matches = find_matches(functions, search)

            if not matches:
                print("No matching functions.")
                continue

            print()
            for index in matches:
                enabled, name = functions[index]
                print_function(index, enabled, name)

            print(f"\nFound {len(matches)} match(es).")

        elif choice == "4":
            name = input("Exact function name: ").strip()

            if not name:
                print("Function name cannot be empty.")
                continue

            changed = set_function(functions, name, True)

            if changed:
                save_config(functions)
                print(f"ENABLED: {name}")
            else:
                print("Function not found, or already enabled.")

        elif choice == "5":
            name = input("Exact function name: ").strip()

            if not name:
                print("Function name cannot be empty.")
                continue

            changed = set_function(functions, name, False)

            if changed:
                save_config(functions)
                print(f"DISABLED: {name}")
            else:
                print("Function not found, or already disabled.")

        elif choice == "6":
            search = input("Enable functions containing: ").strip()

            if not search:
                print("Search cannot be empty.")
                continue

            changed = set_matching(functions, search, True)
            save_config(functions)

            print(f"Enabled {changed} function(s).")

        elif choice == "7":
            search = input("Disable functions containing: ").strip()

            if not search:
                print("Search cannot be empty.")
                continue

            changed = set_matching(functions, search, False)
            save_config(functions)

            print(f"Disabled {changed} function(s).")

        elif choice == "8":
            for i, (_, name) in enumerate(functions):
                functions[i] = (True, name)

            save_config(functions)
            print(f"Enabled ALL {len(functions)} functions.")

        elif choice == "9":
            for i, (_, name) in enumerate(functions):
                functions[i] = (False, name)

            save_config(functions)
            print(f"Disabled ALL {len(functions)} functions.")

        else:
            print("Invalid choice.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="DuckTrace terminal controller"
    )

    parser.add_argument(
        "--list",
        action="store_true",
        help="List all functions",
    )

    parser.add_argument(
        "--list-enabled",
        action="store_true",
        help="List only enabled functions",
    )

    parser.add_argument(
        "--search",
        metavar="TEXT",
        help="List functions containing TEXT",
    )

    parser.add_argument(
        "--enable",
        metavar="FUNCTION",
        help="Enable one exact function name",
    )

    parser.add_argument(
        "--disable",
        metavar="FUNCTION",
        help="Disable one exact function name",
    )

    parser.add_argument(
        "--enable-match",
        metavar="TEXT",
        help="Enable every function containing TEXT",
    )

    parser.add_argument(
        "--disable-match",
        metavar="TEXT",
        help="Disable every function containing TEXT",
    )

    parser.add_argument(
        "--enable-all",
        action="store_true",
        help="Enable every function",
    )

    parser.add_argument(
        "--disable-all",
        action="store_true",
        help="Disable every function",
    )

    args = parser.parse_args()

    # No command-line arguments = interactive terminal mode.
    if len(sys.argv) == 1:
        interactive_mode()
        return

    functions = load_config()

    if args.list:
        list_functions(functions)
        return

    if args.list_enabled:
        list_functions(functions, enabled_only=True)
        return

    if args.search is not None:
        list_functions(functions, search=args.search)
        return

    if args.enable is not None:
        changed = set_function(functions, args.enable, True)

        if changed:
            save_config(functions)
            print(f"ENABLED: {args.enable}")
        else:
            print("Function not found, or already enabled.")
        return

    if args.disable is not None:
        changed = set_function(functions, args.disable, False)

        if changed:
            save_config(functions)
            print(f"DISABLED: {args.disable}")
        else:
            print("Function not found, or already disabled.")
        return

    if args.enable_match is not None:
        changed = set_matching(functions, args.enable_match, True)
        save_config(functions)
        print(f"Enabled {changed} function(s).")
        return

    if args.disable_match is not None:
        changed = set_matching(functions, args.disable_match, False)
        save_config(functions)
        print(f"Disabled {changed} function(s).")
        return

    if args.enable_all:
        for i, (_, name) in enumerate(functions):
            functions[i] = (True, name)

        save_config(functions)
        print(f"Enabled ALL {len(functions)} functions.")
        return

    if args.disable_all:
        for i, (_, name) in enumerate(functions):
            functions[i] = (False, name)

        save_config(functions)
        print(f"Disabled ALL {len(functions)} functions.")
        return


if __name__ == "__main__":
    main()

