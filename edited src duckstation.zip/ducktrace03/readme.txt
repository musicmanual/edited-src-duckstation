Edit src/common/CMakeLists.txt
	add_library(common
			 Assert.cpp
			Binary_reader_writer.cpp
			  …
			 ducktrace.cpp


Put pythons files to /home/lainforall/ducktrace
	ducktrace_controller_terminal.py
	inject_function_logs.py
	
chmod +x the py files

Put ducktrace.cpp and ducktrace.h to /home/lainforall/duckstation/src/common
	edit the ducktrace.cpp txt save path to /home/lainforall/ducktrace


then run the inject_function_logs.py (inject duckTrace function)
	eg python3 inject_function_logs.py \
		--src /home/lainforall/duckstation/src


rebuild duckstation
	cmake -B build-debug-new-detailed
	ninja -C build-debug-new-detailed
	./build-debug-new-detailed/bin/duckstation-qt


start the duckstation
	./build-debug-new-detailed/bin/duckstation-qt
	
	
open another terminal, start controller
	python3 ducktrace_controller_terminal.py
		eg.
			Choice: 4
			Exact function name: core/achievements.cpp:903:Achievements::IdleUpdate