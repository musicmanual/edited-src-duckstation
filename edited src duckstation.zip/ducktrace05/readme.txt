Edit src/common/CMakeLists.txt
	add_library(common
			 Assert.cpp
			Binary_reader_writer.cpp
			  …
			 ducktrace.cpp


Put pythons files to /home/lainforall/ducktrace
	ducktrace_controller_terminal.py
	inject_function_logs.py
	
chmod +x the py files

Put below	to /home/lainforall/duckstation/src/common
	ducktrace.cpp
	ducktrace.h 
	Edit the ducktrace.cpp txt save path to /home/lainforall/ducktrace

Put cpu_code_cache.cpp to /home/lainforall/duckstation/src/core
Put debuggercodeview.cpp  to /home/lainforall/duckstation/src/duckstation-qt


then run the inject_function_logs.py (inject duckTrace function)
	eg python3 inject_function_logs.py \
		--src /home/lainforall/duckstation/src

rebuild duckstation
	cmake -B build-debug-new-detailed
	ninja -C build-debug-new-detailed
	./build-debug-new-detailed/bin/duckstation-qt


start the duckstation
	./build-debug-new-detailed/bin/duckstation-qt
	
	
open another terminal, start controller
	python3 ducktrace_controller_terminal.py
		eg.
			Choice: 4
			Exact function name: ReadBlockInstructions


Edit /home/lainforall/ducktrace/ducktrace_functions.txt, so that it include "CPU::CodeCache::ReadBlockInstructions"
	1|core/cpu_code_cache.cpp:978:CPU::CodeCache::ReadBlockInstructions
	1|CPU::CodeCache::ReadBlockInstructions
	0|core/cpu_core.cpp:1003:BEGIN_FUNCT_INSTRUCTION
	0|core/cpu_core.cpp:1015:BEGIN_FUNCT_INSTRUCTION

			
			
if only want to see instruction sets
	Firstly, disable all under ducktrace_controller_terminal.py
			including "duckstation-qt/debuggercodeview.cpp:284:DebuggerCodeView::drawInstruction"
	then go to /home/lainforall/ducktrace/ducktrace_functions.txt
			add 1|DebuggerCodeView::MY_LABEL
	then open Debug -> CPU Debugger 
	Only my_label will be send to ducktrace.txt