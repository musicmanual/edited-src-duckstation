##JUST to use cpu debugger under duckstation debug

Edit src/common/CMakeLists.txt
	add_library(common
			 Assert.cpp
			Binary_reader_writer.cpp
			  …
			 ducktrace.cpp

Put below	to /home/lainforall/duckstation/src/common
	ducktrace.cpp
	ducktrace.h 
	Edit the ducktrace.cpp txt save path to /home/lainforall/ducktrace

Put edited debuggercodeview.cpp (with ducktrace.h)  to /home/lainforall/duckstation/src/duckstation-qt


rebuild duckstation
	cmake -B build-debug-new-detailed
	ninja -C build-debug-new-detailed
	./build-debug-new-detailed/bin/duckstation-qt


(if first time)
	cd ~/duckstation

	cmake -B build-debug-cpu-debugger \
	 -DCMAKE_C_COMPILER=clang \
	 -DCMAKE_CXX_COMPILER=clang++ \
	 -DCMAKE_EXE_LINKER_FLAGS_INIT="-fuse-ld=lld" \
	 -DCMAKE_MODULE_LINKER_FLAGS_INIT="-fuse-ld=lld" \
	 -DCMAKE_SHARED_LINKER_FLAGS_INIT="-fuse-ld=lld" \
	 -DCMAKE_BUILD_TYPE=Debug \
	 -G Ninja
	ninja -C build-debug-cpu-debugger
	./build-debug-cpu-debugger/bin/duckstation-qt

place ducktrace_functions.txt at /home/lainforall/ducktrace

				
Make sure DebuggerCodeView::MY_LABEL is turn on in "ducktrace_functions.txt"
	Firstly, disable all under ducktrace_controller_terminal.py
			including "duckstation-qt/debuggercodeview.cpp:284:DebuggerCodeView::drawInstruction"
	then go to /home/lainforall/ducktrace/ducktrace_functions.txt
			add 1|DebuggerCodeView::MY_LABEL
	then open Debug -> CPU Debugger 
	Only my_label will be send to ducktrace.txt