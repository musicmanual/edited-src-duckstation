#!/usr/bin/env python3
"""
DuckStation C++ Function INFO_LOG Injector

Scans C/C++ source files with libclang, finds actual function definitions,
shows a dry-run list, then lets you inject:

    INFO_LOG("mylabel_2 - {}", __FUNCTION__);

at the beginning of each function body.

Recommended usage from the DuckStation repository root:

    python3 inject_function_logs.py --src src --compile-commands build-debug/compile_commands.json

Then choose:
    A = apply to all
    S = select individual functions
    Q = quit

The script creates .bak files before changing a source file.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    from clang import cindex
except ImportError:
    print("ERROR: Python libclang bindings are not installed.")
    print()
    print("On Ubuntu, try:")
    print("  sudo apt install python3-clang libclang-dev")
    print()
    print("If you use a virtual environment, you may need:")
    print("  python3 -m pip install clang")
    sys.exit(1)


INJECT_LINE = 'INFO_LOG("mylabel_2 - {}", __FUNCTION__);'
SOURCE_EXTENSIONS = {
    ".cpp", ".cc", ".cxx", ".c++",
    ".hpp", ".hh", ".hxx", ".h++",
    ".h",
}
SKIP_DIRS = {
    ".git", "build", "build-debug", "build-debug-new",
    "build-debug-new-detailed", "node_modules",
}


@dataclass
class FunctionInfo:
    file: Path
    name: str
    line: int
    column: int
    body_start: int
    body_end: int
    display: str


def normalize_path(p: str | Path) -> Path:
    return Path(os.path.realpath(os.path.abspath(str(p))))


def load_compile_commands(path: Path):
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    result = {}

    for entry in data:
        directory = Path(entry.get("directory", "."))
        directory = normalize_path(directory)
        filename = entry.get("file")
        if not filename:
            continue

        file_path = normalize_path(
            directory / filename if not os.path.isabs(filename) else filename
        )

        # Prefer "arguments" if available.
        if "arguments" in entry:
            args = list(entry["arguments"])
        else:
            import shlex
            args = shlex.split(entry.get("command", ""))

        if not args:
            continue

        # libclang.parse_translation_unit() wants arguments without compiler executable.
        if args and Path(args[0]).name in {
            "clang", "clang++", "clang-cc", "clang-cpp",
            "g++", "gcc", "c++", "cc",
        }:
            args = args[1:]

        result[file_path] = (args, directory)

    return result


def get_command_for_file(file_path: Path, compile_commands):
    file_path = normalize_path(file_path)

    if file_path in compile_commands:
        return compile_commands[file_path]

    # A header normally has no compile_commands entry.
    # Try to find a translation unit in compile_commands that includes it.
    # We cannot know this cheaply without parsing, so use a conservative fallback.
    return None


def cursor_is_function_definition(cursor):
    # clang CursorKind.FUNCTION_DECL covers free functions.
    # METHOD_DECL covers class methods.
    # CONSTRUCTOR/CXX_METHOD/DESTRUCTOR cover C++ members.
    kinds = {
        cindex.CursorKind.FUNCTION_DECL,
        cindex.CursorKind.FUNCTION_TEMPLATE,
        cindex.CursorKind.CXX_METHOD,
        cindex.CursorKind.CONSTRUCTOR,
        cindex.CursorKind.DESTRUCTOR,
        cindex.CursorKind.CONVERSION_FUNCTION,
    }

    if cursor.kind not in kinds:
        return False

    try:
        if not cursor.is_definition():
            return False
    except Exception:
        return False

    return True


def cursor_file(cursor):
    try:
        loc = cursor.location
        if loc is None or loc.file is None:
            return None
        return normalize_path(loc.file.name)
    except Exception:
        return None


def read_file(path: Path):
    # DuckStation source is normally UTF-8. errors=surrogateescape keeps
    # unusual bytes round-trippable when writing the file back.
    return path.read_text(encoding="utf-8", errors="surrogateescape")


def offset_from_location(loc):
    # libclang SourceLocation has .offset in current bindings.
    try:
        return int(loc.offset)
    except Exception:
        return None


def find_body_brace(source: str, compound_cursor):
    """
    Find the opening '{' of the CompoundStmt without trying to parse C++.
    Clang has already identified this node as the function body, so this
    search is only over the very small extent of that body.
    """
    start = offset_from_location(compound_cursor.extent.start)
    end = offset_from_location(compound_cursor.extent.end)

    if start is None or end is None:
        return None, None, None

    if start < 0 or end > len(source) or start >= end:
        return None, None, None

    segment = source[start:end]
    brace_rel = segment.find("{")
    if brace_rel < 0:
        return None, None, None

    brace = start + brace_rel
    return brace, start, end


def find_function_body(cursor, source):
    # The first CompoundStmt child of a function definition is its body.
    for child in cursor.get_children():
        if child.kind == cindex.CursorKind.COMPOUND_STMT:
            brace, body_start, body_end = find_body_brace(source, child)
            if brace is not None:
                return brace, body_start, body_end

    return None, None, None


def get_display_name(cursor):
    try:
        spelling = cursor.spelling or cursor.displayname
    except Exception:
        spelling = ""

    # For overloaded functions, displayname can contain parameters.
    # __FUNCTION__ itself only needs the function name, so use spelling.
    return spelling or "<unnamed>"


def collect_functions_from_tu(tu, source_root: Path, source_path: Path, source_text: str):
    found = []

    def visit(cursor):
        cfile = cursor_file(cursor)

        # We only want definitions physically belonging to the file we're
        # currently scanning, not functions from included headers.
        if cfile != source_path:
            return

        if cursor_is_function_definition(cursor):
            brace, body_start, body_end = find_function_body(cursor, source_text)

            if brace is not None:
                found.append(
                    FunctionInfo(
                        file=source_path,
                        name=get_display_name(cursor),
                        line=cursor.location.line,
                        column=cursor.location.column,
                        body_start=body_start,
                        body_end=body_end,
                        display=f"{get_display_name(cursor)}  ({source_path}:{cursor.location.line})",
                    )
                )

        for child in cursor.get_children():
            visit(child)

    visit(tu.cursor)

    # A cursor can occasionally be reached more than once through template
    # instantiations. Deduplicate by source position.
    unique = {}
    for item in found:
        key = (item.file, item.line, item.column, item.body_start)
        unique[key] = item

    return sorted(unique.values(), key=lambda x: (x.line, x.column))


def fallback_args_for_header(file_path: Path):
    """
    Basic header fallback. For DuckStation, compile_commands is preferred.
    This is mainly useful for standalone/simple headers.
    """
    suffix = file_path.suffix.lower()
    if suffix in {".h", ".hh", ".hpp", ".hxx", ".h++"}:
        return [
            "-x", "c++-header",
            "-std=c++20",
        ]
    return ["-std=c++20"]


def parse_file(index, file_path, command_info, source_root):
    source_text = read_file(file_path)

    if command_info:
        args, directory = command_info
    else:
        args = fallback_args_for_header(file_path)
        directory = source_root

    # Remove compile_commands output/dependency flags that can confuse a
    # separate libclang parse. Compilation options are otherwise preserved.
    cleaned = []
    skip_next = False
    for arg in args:
        if skip_next:
            skip_next = False
            continue

        # The original source file is already supplied by libclang.
        if normalize_path(arg) == file_path:
            continue

        # compile_commands may contain output flags such as -o foo.o.
        if arg == "-o":
            skip_next = True
            continue
        if arg.startswith("-o") and len(arg) > 2:
            continue

        cleaned.append(arg)

    options = (
        cindex.TranslationUnit.PARSE_DETAILED_PROCESSING_RECORD
        | cindex.TranslationUnit.PARSE_INCOMPLETE
    )

    try:
        old_cwd = os.getcwd()
        os.chdir(directory)
        try:
            tu = index.parse(
                str(file_path),
                args=cleaned,
                options=options,
            )
        finally:
            os.chdir(old_cwd)
    except Exception as e:
        return [], f"parse error: {e}"

    # Diagnostics are useful but don't prevent us from using a partial AST.
    errors = [
        str(d)
        for d in tu.diagnostics
        if d.severity >= cindex.Diagnostic.Error
    ]

    funcs = collect_functions_from_tu(
        tu, source_root, file_path, source_text
    )

    return funcs, "; ".join(errors[:3]) if errors else None


def insertion_text(source: str, brace_offset: int):
    """
    Put the log immediately after the opening brace, preserving the function
    body's indentation style.

    Example:
        void Foo()
        {
            ...
        }

    becomes:
        void Foo()
        {
            INFO_LOG(...);
            ...
        }
    """
    line_start = source.rfind("\n", 0, brace_offset) + 1
    brace_column = brace_offset - line_start

    # Find indentation of the first non-empty line after the brace.
    pos = brace_offset + 1
    while pos < len(source) and source[pos] in " \t":
        pos += 1

    if pos < len(source) and source[pos] == "\n":
        # Empty line immediately after brace.
        next_line_start = pos + 1
    else:
        next_line_start = pos

    line_end = source.find("\n", next_line_start)
    if line_end < 0:
        line_end = len(source)

    first_line = source[next_line_start:line_end]

    m = re.match(r"[ \t]*", first_line)
    existing_indent = m.group(0) if m else ""

    # If the next line is immediately a closing brace, use a reasonable
    # indentation based on the brace line.
    if not first_line.strip():
        indent = existing_indent + ("    " if "\t" not in existing_indent else "\t")
    elif first_line.strip() == "}":
        indent = existing_indent + ("    " if "\t" not in existing_indent else "\t")
    else:
        indent = existing_indent

    # Insert on a fresh line.
    return "\n" + indent + INJECT_LINE + "\n"


def already_injected(source: str, func: FunctionInfo):
    body = source[func.body_start:func.body_end]
    return "mylabel_2 -" in body or INJECT_LINE in body


def apply_to_file(path: Path, functions):
    source = read_file(path)

    # Insert from bottom to top so offsets remain valid.
    changes = []

    for func in functions:
        if already_injected(source, func):
            continue

        # Recalculate body brace from the saved body start. Since this file
        # has not been modified yet, the original offsets are valid.
        body_segment = source[func.body_start:func.body_end]
        rel = body_segment.find("{")
        if rel < 0:
            continue

        brace = func.body_start + rel

        # Avoid duplicate if some variant is already immediately in body.
        after = source[brace:func.body_end]
        if "mylabel_2 -" in after[:500]:
            continue

        changes.append((brace + 1, insertion_text(source, brace)))

    if not changes:
        return False

    # Backup once per modified file.
    backup = Path(str(path) + ".bak")
    if not backup.exists():
        shutil.copy2(path, backup)

    for offset, text in sorted(changes, reverse=True):
        source = source[:offset] + text + source[offset:]

    path.write_text(source, encoding="utf-8", errors="surrogateescape")
    return True


def print_functions(functions):
    if not functions:
        print("  (none)")
        return

    for i, func in enumerate(functions, 1):
        print(f"  [{i:4}] {func.display}")


def main():
    parser = argparse.ArgumentParser(
        description="Inject INFO_LOG at the beginning of C++ function definitions."
    )
    parser.add_argument(
        "--src",
        required=True,
        help="DuckStation source directory, e.g. ~/duckstation/src",
    )
    parser.add_argument(
        "--compile-commands",
        default=None,
        help="Path to compile_commands.json",
    )
    parser.add_argument(
        "--include-headers",
        action="store_true",
        help="Also scan .h/.hpp/etc. files. Header parsing uses a fallback when "
             "the header has no compile_commands entry.",
    )
    args = parser.parse_args()

    source_root = normalize_path(args.src)
    if not source_root.is_dir():
        print(f"ERROR: source directory does not exist: {source_root}")
        sys.exit(1)

    compile_commands = {}
    if args.compile_commands:
        cc_path = normalize_path(args.compile_commands)
        if not cc_path.is_file():
            print(f"ERROR: compile_commands.json not found: {cc_path}")
            sys.exit(1)
        compile_commands = load_compile_commands(cc_path)
    else:
        print("WARNING: no compile_commands.json supplied.")
        print("         DuckStation files may fail to parse because of missing")
        print("         project-specific compiler definitions/includes.")
        print()

    allowed_exts = {".cpp", ".cc", ".cxx", ".c++"}
    if args.include_headers:
        allowed_exts |= SOURCE_EXTENSIONS - {".cpp", ".cc", ".cxx", ".c++"}

    files = []
    for path in source_root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path.suffix.lower() in allowed_exts:
            files.append(normalize_path(path))

    files.sort()

    print(f"Source root: {source_root}")
    print(f"Files to scan: {len(files)}")
    print()

    index = cindex.Index.create()
    all_functions = []
    parse_failures = []

    for n, path in enumerate(files, 1):
        print(f"[{n}/{len(files)}] {path.relative_to(source_root)}")

        funcs, error = parse_file(
            index,
            path,
            get_command_for_file(path, compile_commands),
            source_root,
        )

        if error:
            parse_failures.append((path, error))

        for f in funcs:
            all_functions.append(f)

    print()
    print("=" * 80)
    print(f"FUNCTIONS FOUND: {len(all_functions)}")
    print("=" * 80)
    print_functions(all_functions)

    if parse_failures:
        print()
        print("=" * 80)
        print(f"PARSE WARNINGS: {len(parse_failures)}")
        print("=" * 80)
        for path, error in parse_failures[:30]:
            print(f"- {path}: {error}")
        if len(parse_failures) > 30:
            print(f"... and {len(parse_failures) - 30} more")

    if not all_functions:
        print()
        print("No function definitions were found.")
        print("For DuckStation, make sure you supplied the correct")
        print("compile_commands.json.")
        return

    print()
    print("DRY RUN COMPLETE.")
    print()
    print("Choose:")
    print("  A = apply to ALL functions")
    print("  S = select individual functions")
    print("  Q = quit without changes")
    print()

    choice = input("> ").strip().lower()

    if choice == "q":
        print("No changes made.")
        return

    selected = []

    if choice == "a":
        selected = all_functions

    elif choice == "s":
        print()
        print("Enter function numbers separated by spaces or commas.")
        print("Example: 1 4 8 12")
        print("You can also enter ranges, e.g. 1-10.")
        print()

        raw = input("Functions > ").strip()

        numbers = set()
        for token in re.split(r"[,\s]+", raw):
            if not token:
                continue

            if "-" in token:
                try:
                    a, b = token.split("-", 1)
                    a, b = int(a), int(b)
                    numbers.update(range(min(a, b), max(a, b) + 1))
                except ValueError:
                    print(f"Ignoring invalid range: {token}")
            else:
                try:
                    numbers.add(int(token))
                except ValueError:
                    print(f"Ignoring invalid number: {token}")

        selected = [
            func for i, func in enumerate(all_functions, 1)
            if i in numbers
        ]

    else:
        print("Unknown choice. No changes made.")
        return

    if not selected:
        print("Nothing selected. No changes made.")
        return

    print()
    print("=" * 80)
    print(f"SELECTED: {len(selected)}")
    print("=" * 80)
    print_functions(selected)

    print()
    confirm = input("Type APPLY to modify the files: ").strip()

    if confirm != "APPLY":
        print("Confirmation not received. No changes made.")
        return

    by_file = {}
    for func in selected:
        by_file.setdefault(func.file, []).append(func)

    modified = 0
    skipped = 0

    print()
    print("Applying changes...")

    for path, funcs in sorted(by_file.items()):
        try:
            changed = apply_to_file(path, funcs)
            if changed:
                modified += 1
                print(f"  MODIFIED: {path}")
            else:
                skipped += 1
                print(f"  SKIPPED:  {path} (already injected or nothing applicable)")
        except Exception as e:
            print(f"  ERROR:    {path}: {e}")

    print()
    print("=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"Files modified: {modified}")
    print(f"Files skipped:  {skipped}")
    print()
    print("Backup files use the .bak extension.")
    print("Example:")
    print("  src/core/system.cpp.bak")


if __name__ == "__main__":
    main()
